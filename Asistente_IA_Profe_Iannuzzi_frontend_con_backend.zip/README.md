# Asistente IA del Profe Iannuzzi

Asistente IA creado para responder preguntas de los alumnos del Profe Iannuzzi relativas a las materias que cursan con �l.
La IA es entrenada con el material desarrollado por el Esp. Prof. Ing. Tec. Marcos Iannuzzi.

Desplegable en Render, Acceso con contrase�a

## Caracter�stica:
- Tenga Paciencia, se utilizan recursos gratuitos para este asistente, por lo que no tendr� la performance de las IA disponibles en internet.


